#pragma once
struct fraction {
	double salary;
	int days;
	void Init(double, int);
	void Read();
	void Show();
	double Summa();
};